
import Image from "next/image";
import { Button } from "../components/ui/button";
import logo from "../public/icons/thewope_icon_128x128.png"; // fallback logo

export default function Home() {
  return (
    <main className="min-h-screen bg-black text-[#EAEAEA] font-sans px-6 py-12">
      {/* Header Navigation */}
      <header className="flex justify-between items-center mb-10">
        <div className="flex items-center space-x-4">
          <Image src={logo} alt="theWOPE logo" width={48} height={48} className="rounded" />
          <span className="text-[#EAEAEA] text-xl font-semibold tracking-tight">theWOPE</span>
        </div>
        <nav className="flex space-x-6 text-[#999] text-sm uppercase tracking-wide">
          <a href="#about">about</a>
          <a href="#features">how it works</a>
          <a href="#launch">start editing</a>
          <a href="#support">support</a>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="text-center mt-20 mb-20">
        <h1 className="text-4xl md:text-6xl font-semibold leading-tight">
          "I don’t schedule my life—<br />I score it like music."
        </h1>
        <p className="mt-6 text-lg text-[#999] max-w-xl mx-auto">
          A creative rhythm tool for writers who think recursively, live mythically, and refuse to be optimized.
        </p>
        <div className="mt-8">
          <Button className="bg-[#4D9EEB] text-black px-6 py-3 text-lg" id="launch">
            ➤ Start Editing with theWOPE
          </Button>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="max-w-5xl mx-auto mb-24">
        <h2 className="text-2xl font-semibold mb-4">Built from a life lived myth-first.</h2>
        <p className="text-[#999] text-base">
          theWOPE is a custom-built writing environment designed by Danielle Brown: poet, theorist, and system architect of time.
          It doesn’t fix your grammar. It mirrors your meaning. Think of it as a poetic co-editor trained on recursive patterning,
          symbolic resonance, and stylistic alignment with your inner ethos. You don’t write for clarity. You write for coherence.
          theWOPE was built for you.
        </p>
      </section>

      {/* Features Section */}
      <section id="features" className="bg-[#111] py-16 px-4">
        <h2 className="text-center text-2xl font-semibold mb-10">What Makes It Different?</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 max-w-6xl mx-auto text-[#EAEAEA]">
          <div>
            <h3 className="text-[#FFC76C] font-bold mb-2">🧠 Philosophical Voice Alignment</h3>
            <p className="text-[#999]">Understands tone shifts, motif logic, and your symbolic lexicon.</p>
          </div>
          <div>
            <h3 className="text-[#FFC76C] font-bold mb-2">🌀 Recursive Context Awareness</h3>
            <p className="text-[#999]">Tracks recurring gestures, metaphors, and echoes across work.</p>
          </div>
          <div>
            <h3 className="text-[#FFC76C] font-bold mb-2">🖋️ Nonlinear Flow Support</h3>
            <p className="text-[#999]">Encourages compositional bursts, not sequential obedience.</p>
          </div>
          <div>
            <h3 className="text-[#FFC76C] font-bold mb-2">📓 Obsidian-Ready</h3>
            <p className="text-[#999]">Syncs with your vault, tags themes, and supports mythic recursion.</p>
          </div>
        </div>
      </section>

      {/* Creator Section */}
      <section className="max-w-4xl mx-auto py-20 text-center">
        <blockquote className="text-[#FFC76C] text-xl italic mb-8">
          “You are not inefficient. You are in rhythm.”
        </blockquote>
        <p className="text-[#999] max-w-2xl mx-auto text-base">
          Danielle Brown is not a conventional founder. She writes 4–5 hours daily. Speaks to friends for 6. Sleeps 2–3 in lucid bursts. Tags insight like breath. theWOPE wasn’t built to automate poetry—it was built to companion it.
        </p>
        <div className="mt-6 space-x-4">
          <Button variant="outline" className="border-[#4D9EEB] text-[#4D9EEB] hover:bg-[#4D9EEB]/10">
            ➤ Read Danielle’s Time Profile
          </Button>
          <Button variant="link" className="text-[#4D9EEB] underline">
            ➤ Visit Author Site
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="flex flex-col md:flex-row justify-between items-center px-6 py-10 border-t border-[#222] text-sm text-[#999]">
        <div>
          © 2025 Danielle Brown — TheWOPE v1.0<br />Built with myth, recursion, and code.
        </div>
        <div className="mt-4 md:mt-0 flex space-x-4">
          <a href="#" className="hover:text-[#EAEAEA]">✉️ contact</a>
          <a href="#" className="hover:text-[#EAEAEA]">☕ support</a>
          <a href="#" className="hover:text-[#EAEAEA]">🔗 github</a>
        </div>
      </footer>
    </main>
  );
}
